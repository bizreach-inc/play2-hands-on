java -cp h2-1.4.192.jar org.h2.tools.Server -tcp -web -baseDir .
